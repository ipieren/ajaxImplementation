﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(RecipeClient002.Startup))]
namespace RecipeClient002
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
