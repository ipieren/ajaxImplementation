﻿using System.Web.UI;

namespace RecipeClient002.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}