﻿using System.Web.UI;

namespace RecipeClient.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}