﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using RecipeDataAccess;
using SecurityDataAccess;
using RecipeService.Models;
using System.Web.Http.Cors;

namespace RecipeService.Controllers
{
    [EnableCors("*",                    // Origin
              null,                     // Request headers
              "GET",                    // HTTP methods
              "bar",                    // Response headers
              SupportsCredentials = true  // Allow credentials
  )]

    
    public class RecipeAuthController : ApiController
    {

        //this resource is for all types of role
        
        [Authorize(Roles = "Admin")]
        [HttpGet]
        [Route("api/interface/recipes")]
        
        public HttpResponseMessage GetRecipes()
        {
            using (RecipeDBEntities entities = new RecipeDBEntities())
            { 
                return Request.CreateResponse(HttpStatusCode.OK, entities.Recipes.ToList());
            }
        }


        //User login
        [Authorize(Roles = "Admin")]
        [Route("api/user/login")]
        [HttpPost]
        public HttpResponseMessage Login(Credential credential)
        {
            try
            {

            using (SECURITY_DBEntities entities = new SECURITY_DBEntities())
            {
                var users = entities.UserMasters.FirstOrDefault(x => x.UserName == credential.username
                && x.UserPassword == credential.password);

                return Request.CreateResponse(HttpStatusCode.OK, users);
            }

            }
            catch(Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }


        }

        

        [Authorize(Roles = "Admin")]
        [HttpPost]
        [Route("api/interface/recipes")]

        //[BasicAuthentication]
        //23/05/2020 = changed post method to original

        //24-05-2020 = added id parameter to Post method which doesnt work
        public HttpResponseMessage PostRecipes([FromBody] Recipe recipe)
        {
            try
            {
                using (RecipeDBEntities entities = new RecipeDBEntities())
                {

                    entities.Recipes.Add(recipe);
                    entities.SaveChanges();

                    var message = Request.CreateResponse(HttpStatusCode.Created, recipe);
                    message.Headers.Location = new Uri(Request.RequestUri + "/" + recipe.ID.ToString());
                    return message;
                }
            }
            catch (Exception e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, e);
            }
        }



        ///////////////////PUT METHOD//////////////////////////

         [Authorize(Roles = "Admin")]
        [HttpPut]
        [Route("api/interface/recipes/{id}")]
        public HttpResponseMessage Put(int id, [FromBody] Recipe recipe)
        {
            try
            {
                using (RecipeDBEntities entities = new RecipeDBEntities())
                {
                    var entity = entities.Recipes.FirstOrDefault(e => e.ID == id);
                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee " + id.ToString() + "Not founds!!");
                    }
                    else
                    {
                        entity.Recipe1 = recipe.Recipe1;
                        entity.Complexity = recipe.Complexity;
                        entity.Time = recipe.Time;

                        entities.SaveChanges();

                        return Request.CreateResponse(HttpStatusCode.OK, entity);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }


        [Authorize(Roles = "Admin")]
        [HttpDelete]
        [Route("api/interface/recipes/{id}")]
        public HttpResponseMessage DeleteRecipes(int id)
        {
            try
            {
                using (RecipeDBEntities entities = new RecipeDBEntities())
                {

                    var entity = entities.Recipes.FirstOrDefault(e => e.ID == id);

                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Employee with id = " + id.ToString() + "not found.");
                    }
                    else
                    {
                        entities.Recipes.Remove(entity);
                        entities.SaveChanges();
                        return Request.CreateResponse(HttpStatusCode.OK);

                    }
                }
            }

            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }

        }

    }




    ///////////////////////////////DELETE METHOD////////////////////////



}
