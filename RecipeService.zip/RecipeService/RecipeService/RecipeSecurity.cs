﻿using RecipeDataAccess;
using System;
using System.Linq;

namespace RecipeService
{
    public class RecipeSecurity
    {
        public static bool Login(string username, string password)
        {
            using (RecipeDBEntities entities = new RecipeDBEntities())
            {
                return entities.Users.Any(user => user.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && user.Password == password);


            }
        }
    }
}